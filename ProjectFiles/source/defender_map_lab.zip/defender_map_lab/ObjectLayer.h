#ifndef __ObjectLayer_h_INCLUDE
#define __ObjectLayer_h_INCLUDE

#define ObjectLayerWidth 32
#define ObjectLayerHeight 18

extern const unsigned char ObjectLayer[];

#endif
