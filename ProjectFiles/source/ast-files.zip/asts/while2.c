fred(){
int y;
int x;
y=9;
x=4;
while (y>2){
   y=y-1;
   x=x+y;
}
}
