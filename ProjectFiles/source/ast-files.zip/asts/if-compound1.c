ggg(){
int y;
int y1;
y=0;
y1=0;
if (y==y1+1) y=9;
else{
   y=8;
   y1 =3;
   if (y1 == 3)
     y1=2;
}
}

