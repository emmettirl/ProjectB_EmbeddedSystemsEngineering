ggg(){
int y;
int y1;
y=0;
y1=0;
if (y==y1+1) y=9;
else
   y=8;
}

