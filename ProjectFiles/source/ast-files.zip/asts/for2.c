fred(){
int y;
int x;
x=4;
for (y=9;y>2;y=y-1)
   y=y-1;
}
