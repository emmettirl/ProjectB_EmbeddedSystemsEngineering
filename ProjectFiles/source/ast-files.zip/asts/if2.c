fred(){
int y=9;
int x;
x=4;
if (y==9)
   x=7;
else
   x=3;
}
