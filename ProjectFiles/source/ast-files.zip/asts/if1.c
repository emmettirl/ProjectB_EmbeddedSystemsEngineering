fred(){
int y;
int x;
y=9;
x=4;
if (y==9)
   x=7;
}
